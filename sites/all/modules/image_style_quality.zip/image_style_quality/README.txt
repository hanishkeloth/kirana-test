Welcome to the image style quality module.

All you need to do to get this module running should be to install it. No 
other steps should be necessary. If you encounter any bugs, please report them
on Drupal.org.


CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Example
 * Extending
 * Installation


INTRODUCTION
------------

Current Maintainer: PDNagilum <pdnagilum@gmail.com>

This little module gives you the ability to switch to any user via the admin
panel found at admin/people in Drupal 7. It adds an extra link in the
operations-section called 'switch'. Click it and you'll be logged in as that
user.

You can also switch to a user by using a URL, switch-user/%uid. If you have
the correct privileges the system will log you in as the given user.

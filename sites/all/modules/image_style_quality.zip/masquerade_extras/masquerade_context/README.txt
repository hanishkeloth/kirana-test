Context support for Masquerade
------------------------------
Requires: Masquerade
Requires: Context

This provides a Context condition which allows the site to identify
when the current user is masquerading as someone else.

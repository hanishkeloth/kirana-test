Chaos Tools Support for Masquerade
----------------------------------
Requires: Chaos Tool Suite
Requires: Masquerade

This modules provides a Chaos Tools access plugin which allows the site
to determine if the current user is masquerading as someone else.

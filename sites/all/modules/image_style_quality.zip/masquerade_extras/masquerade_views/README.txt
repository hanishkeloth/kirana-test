Masquerade Views
----------------
Requires: Masquerade
Requires: Views 2.x or 3.x

This module provides Views support for Masquerade, allowing site builders
to create views which have access to the list of users being masqueraded,
and can generate links to immediately switch to another user.

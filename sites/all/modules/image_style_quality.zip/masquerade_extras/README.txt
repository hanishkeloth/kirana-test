Masquerade Extras
Provides additional functionality for the Masquerade module.

To make it work you need to download the Zocial CSS social buttons from
https://github.com/samcollins/css-social-buttons/ and unpack it into
'sites/all/libraries/zocial' directory so that we can include the
'sites/all/libraries/zocial/css/zocial.css' CSS file.
// $Id:

Note that these files are slightly modified from the original demonstration files provided in the purr download.

I have modified the css and images to include an error colour for Drupal error messages. This can be expanded further with the css and more images.

The files were originally released under the MIT licence but are now under Drupal's GPL. They are modified versions of files created by Net Perspective: http://net-perspective.com/
